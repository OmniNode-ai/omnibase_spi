"""
Core Protocol Interfaces

System-level contracts for serialization, schema loading, workflow processing,
logging, and other core functionality.
"""

from omnibase.protocols.core.protocol_simple_example import (
    ProtocolSimpleSerializer,
    ProtocolSimpleLogger,
    ProtocolSimpleEventHandler,
)

__all__ = [
    "ProtocolSimpleSerializer",
    "ProtocolSimpleLogger",
    "ProtocolSimpleEventHandler",
]