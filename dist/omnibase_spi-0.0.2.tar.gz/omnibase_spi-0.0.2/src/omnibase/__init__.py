"""
ONEX Service Provider Interface (omnibase-spi)

Pure protocol interfaces for the ONEX framework with zero implementation dependencies.
"""

__version__ = "0.1.0"
__author__ = "OmniNode Team"
__email__ = "team@omninode.ai"
